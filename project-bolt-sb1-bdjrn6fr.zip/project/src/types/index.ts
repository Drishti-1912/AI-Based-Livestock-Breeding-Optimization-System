export interface Animal {
  id: string;
  name: string;
  species: string;
  breed: string;
  gender: 'male' | 'female';
  birthDate: string;
  geneticTraits: {
    health: number;
    fertility: number;
    growth: number;
    productivity: number;
  };
  parentIds?: {
    mother?: string;
    father?: string;
  };
}

export interface BreedingPair {
  maleId: string;
  femaleId: string;
  compatibilityScore: number;
  traits: {
    health: number;
    fertility: number;
    growth: number;
    productivity: number;
  };
}