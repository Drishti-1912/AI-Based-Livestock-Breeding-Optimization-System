import React, { useState } from 'react';
import { Header } from './components/Header';
import { AnimalCard } from './components/AnimalCard';
import { BreedingPairCard } from './components/BreedingPairCard';
import { Animal, BreedingPair } from './types';

// Sample data - in a real app, this would come from an API
const sampleAnimals: Record<string, Animal> = {
  'a1': {
    id: 'a1',
    name: 'Zeus',
    species: 'Cattle',
    breed: 'Angus',
    gender: 'male',
    birthDate: '2020-03-15',
    geneticTraits: {
      health: 85,
      fertility: 90,
      growth: 88,
      productivity: 92
    }
  },
  'a2': {
    id: 'a2',
    name: 'Hera',
    species: 'Cattle',
    breed: 'Hereford',
    gender: 'female',
    birthDate: '2021-01-20',
    geneticTraits: {
      health: 92,
      fertility: 88,
      growth: 85,
      productivity: 87
    }
  }
};

const sampleBreedingPairs: BreedingPair[] = [
  {
    maleId: 'a1',
    femaleId: 'a2',
    compatibilityScore: 89,
    traits: {
      health: 88,
      fertility: 89,
      growth: 86,
      productivity: 90
    }
  }
];

function App() {
  const [selectedAnimal, setSelectedAnimal] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <section>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-800">Livestock Inventory</h2>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Add Animal
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.values(sampleAnimals).map((animal) => (
                <AnimalCard
                  key={animal.id}
                  animal={animal}
                  onClick={() => setSelectedAnimal(animal.id)}
                />
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-gray-800 mb-6">Recommended Breeding Pairs</h2>
            <div className="space-y-4">
              {sampleBreedingPairs.map((pair, index) => (
                <BreedingPairCard
                  key={index}
                  pair={pair}
                  animals={sampleAnimals}
                />
              ))}
            </div>
          </section>
        </div>

        <section className="mt-12">
          <h2 className="text-xl font-semibold text-gray-800 mb-6">AI Insights</h2>
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h3 className="font-medium text-blue-800 mb-2">Herd Health Score</h3>
                <p className="text-3xl font-bold text-blue-600">87%</p>
                <p className="text-sm text-gray-600 mt-2">Above average genetic diversity</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <h3 className="font-medium text-green-800 mb-2">Breeding Success Rate</h3>
                <p className="text-3xl font-bold text-green-600">92%</p>
                <p className="text-sm text-gray-600 mt-2">Based on historical data</p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <h3 className="font-medium text-purple-800 mb-2">Optimization Score</h3>
                <p className="text-3xl font-bold text-purple-600">85%</p>
                <p className="text-sm text-gray-600 mt-2">Room for improvement in fertility traits</p>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;