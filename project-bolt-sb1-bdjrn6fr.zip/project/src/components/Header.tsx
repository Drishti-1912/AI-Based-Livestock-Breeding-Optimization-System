import React from 'react';
import { Brain } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-6">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Brain size={32} className="text-blue-200" />
            <div>
              <h1 className="text-2xl font-bold">LiveStock AI</h1>
              <p className="text-blue-200 text-sm">Breeding Optimization System</p>
            </div>
          </div>
          <nav className="hidden md:flex space-x-6">
            <a href="#dashboard" className="hover:text-blue-200 transition-colors">Dashboard</a>
            <a href="#analysis" className="hover:text-blue-200 transition-colors">Analysis</a>
            <a href="#breeding" className="hover:text-blue-200 transition-colors">Breeding Pairs</a>
          </nav>
        </div>
      </div>
    </header>
  );
}