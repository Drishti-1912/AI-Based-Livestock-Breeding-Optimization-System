import React from 'react';
import { BreedingPair } from '../types';

interface BreedingPairCardProps {
  pair: BreedingPair;
  animals: Record<string, any>;
}

export function BreedingPairCard({ pair, animals }: BreedingPairCardProps) {
  const male = animals[pair.maleId];
  const female = animals[pair.femaleId];

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Breeding Pair</h3>
        <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
          {pair.compatibilityScore}% Match
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="p-3 bg-blue-50 rounded-lg">
          <p className="font-medium text-blue-800">Male</p>
          <p className="text-sm text-gray-600">{male.name}</p>
          <p className="text-sm text-gray-600">{male.breed}</p>
        </div>
        <div className="p-3 bg-pink-50 rounded-lg">
          <p className="font-medium text-pink-800">Female</p>
          <p className="text-sm text-gray-600">{female.name}</p>
          <p className="text-sm text-gray-600">{female.breed}</p>
        </div>
      </div>

      <div className="space-y-2">
        <h4 className="text-sm font-medium text-gray-700">Predicted Offspring Traits</h4>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(pair.traits).map(([trait, value]) => (
            <div key={trait} className="flex items-center">
              <span className="text-xs text-gray-600 capitalize">{trait}:</span>
              <div className="ml-2 h-2 w-16 bg-gray-200 rounded-full">
                <div 
                  className="h-full bg-green-600 rounded-full"
                  style={{ width: `${value}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}