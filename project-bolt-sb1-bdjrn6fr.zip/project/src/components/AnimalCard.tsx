import React from 'react';
import { Animal } from '../types';

interface AnimalCardProps {
  animal: Animal;
  onClick?: () => void;
}

export function AnimalCard({ animal, onClick }: AnimalCardProps) {
  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow cursor-pointer"
    >
      <div className="flex justify-between items-start mb-3">
        <h3 className="text-lg font-semibold text-gray-800">{animal.name}</h3>
        <span className={`px-2 py-1 rounded-full text-xs ${
          animal.gender === 'male' ? 'bg-blue-100 text-blue-800' : 'bg-pink-100 text-pink-800'
        }`}>
          {animal.gender}
        </span>
      </div>
      
      <div className="space-y-2">
        <p className="text-sm text-gray-600">Breed: {animal.breed}</p>
        <p className="text-sm text-gray-600">Age: {new Date().getFullYear() - new Date(animal.birthDate).getFullYear()} years</p>
        
        <div className="mt-3">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Genetic Traits</h4>
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(animal.geneticTraits).map(([trait, value]) => (
              <div key={trait} className="flex items-center">
                <span className="text-xs text-gray-600 capitalize">{trait}:</span>
                <div className="ml-2 h-2 w-16 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-blue-600 rounded-full"
                    style={{ width: `${value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}